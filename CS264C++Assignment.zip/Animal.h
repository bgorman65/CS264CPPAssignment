#ifndef ANIMAL_H
#define ANIMAL_H
// Importing needed libraries
#include <string>
// Defining Scope
using namespace std;
// Creating new scope to be used later on
namespace AnimalWorld{
    // Creating layout for Animal object
	class Animal{
        // Public attributes
		public:
            // Enumeration for color selection
			enum Color {red, green, blue, white, brown, orange, yellow, rainbow, unknown};
			// Constructors
            Animal();
			Animal(string, Color);
			Animal(string,Color,string);
			Animal(Animal& animal):_name(animal.getName()),_color(animal.getColor()),_food(animal.getFood()){}
			// Various needed function to manipulate other attributes
            virtual string toString();
			void setColor(Color);
			Color getColor();
			void setFood(string);
			string getFood();
			void setName(string);
			string getName();
			virtual string walk();

        // Protected attributes
		protected:
			string getColor(Color);

        // Private attributes to hold data of the object
		private:
			Color _color;
			string _food;
			string _name;
	};
}

#endif