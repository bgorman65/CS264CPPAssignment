#ifndef DUBLINZOO_H
#define DUBLINZOO_H
// Importing needed files
#include "Zoo.h"

// Creating the DublinZoo object extending off the Zoo object
class DublinZoo: public Zoo{
    // Public attributes
    public:
        // Constructor
        DublinZoo(unsigned int, string, string);
        // Various functions and attributes
        string getTime();
        string getWeather();

    // Private attributes
    private:
        string _showTime;
        string _weather;
};

#endif