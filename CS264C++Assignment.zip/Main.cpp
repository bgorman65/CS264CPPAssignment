// Importing Needed Libraries and Files
#include <iostream>
#include "Animal.h"
#include "Zoo.h"
#include "Dog.h"
#include "Bird.h"
#include "Gorilla.h"
#include "Lion.h"
#include "DublinZoo.h"
#include "TexasZoo.h"

int main(){
    // Creating animal objects for the Dublin Zoo
	Animal *KingKong = new Gorilla("King Kong", Animal::Color::brown, "fruit");
	Animal *JimmyJoe = new Bird("Jimmy Joe", Animal::Color::red, "seeds");
    Animal *Mane = new Lion("Mane", Animal::Color::orange, "meat");
    Animal *Whiskers = new Dog("Whiskers", Animal::Color::white, "anything");
    // Creating the instance of the Dublin Zoo
	DublinZoo *dublin_zoo = new DublinZoo(15, "12:30pm", "Raining");
    // Adding the Animals into the zoo
	dublin_zoo->addAnimal(KingKong);
	dublin_zoo->addAnimal(JimmyJoe);
    dublin_zoo->addAnimal(Mane);
    dublin_zoo->addAnimal(Whiskers);
    // Various Print Statements for the show
    cout<<"***Dublin Zoo Animal Show***"<<endl;
    cout<<"Time: "<<dublin_zoo->getTime()<<endl;
    cout<<"Weather: "<< dublin_zoo->getWeather()<<endl;
    cout<<"Animals to Perform and Various Information:"<<endl;
	cout<<dublin_zoo->toString()<<"\n"<<endl;
    // Creating animal objects for the Texas Zoo
    Animal *Jack = new Dog("Jack",Animal::Color::brown, "dog food");
    Animal *Bill = new Bird("Bill",Animal::Color::brown, "worms");
    Animal *Bob = new Gorilla("Bob",Animal::Color::brown, "bananas");
    Animal *Andrew = new Lion("Andrew",Animal::Color::brown, "zebras");
    // Creating the instance of the Texas Zoo
    TexasZoo *fortworth_zoo = new TexasZoo(15, "1:00pm", "Sunny", "Fort Worth");
    // Adding the animals into the instance of the Texas Zoo
    fortworth_zoo->addAnimal(Jack);
    fortworth_zoo->addAnimal(Bill);
    fortworth_zoo->addAnimal(Bob);
    fortworth_zoo->addAnimal(Andrew);
    // Various Print Statements for the show at the Texas Zoo
    cout<<"***Texas Zoo Animal Show***"<<endl;
    cout<<"City: "<<fortworth_zoo->getCity()<<endl;
    cout<<"Time: "<<fortworth_zoo->getTime()<<endl;
    cout<<"Weather: "<<fortworth_zoo->getWeather()<<endl;
    cout<<"Animals to Perform and Various Information:"<<endl;
    cout<<fortworth_zoo->toString()<<"\n"<<endl;
    // Deleting the instances of the Animals and the Zoos;
    delete KingKong;
    delete JimmyJoe;
    delete Mane;
    delete Whiskers;
    delete dublin_zoo;
    delete Jack;
    delete Bill;
    delete Bob;
    delete Andrew;
    delete fortworth_zoo;
	return 0;
}

