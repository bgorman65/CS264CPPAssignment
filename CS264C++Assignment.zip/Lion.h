#ifndef LION_H
#define LION_H
// Importing needed files
#include "Animal.h"
// Defining scope
using namespace AnimalWorld;
// Creating layout of Lion object extending off the Animal object
class Lion : public Animal{
    // Public Attributes
    public:
        // Constructors
        Lion();
        Lion(string, Color, string);
        // Various functions and attributes needed for object
        string perform();
        string toString();
};

#endif