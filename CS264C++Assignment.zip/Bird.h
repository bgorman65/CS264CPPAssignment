#ifndef BIRD_H
#define BIRD_H
// Importing needed files
#include "Animal.h"
// Defining scope
using namespace AnimalWorld;
// Creating layout of Bird object extending off the Animal object
class Bird : public Animal{
    // Public Attributes
	public:
        // Constructors
        Bird();
		Bird(string, Color, string);
        // Various functions and attributes needed for object
        string perform();
        string toString();
};

#endif