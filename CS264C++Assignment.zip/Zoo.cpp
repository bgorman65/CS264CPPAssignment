#include "Zoo.h"


Zoo::Zoo(unsigned int capacity){
	this->_animals=NULL;
	if (capacity==0) return;
	this->_animals = new Animal*[capacity];
	this->_size=0;
	this->_capacity=capacity;
}

void Zoo::addAnimal(Animal& animal){
	if (this->_size>=this->_capacity) return;
	this->_animals[this->_size++]=&animal;
}

void Zoo::addAnimal(Animal* animal){
	if (this->_size>=this->_capacity) return;
	this->_animals[this->_size++]=animal;	
}

Animal* Zoo::getAnimal(unsigned int k){
	if (k>=this->_size)
		return NULL;
	else	
		return this->_animals[k];
}

Animal** Zoo::getAllAnimals(){
	return this->_animals;
}

int Zoo::size(){
	return this->_size;
}

Zoo::~Zoo(){
	if (this->_animals==NULL) return;
	delete[] _animals;
}

string Zoo::toString(){
	string str="";
	if (this->_animals == NULL){
        return "Zoo is empty";
    }
	for (int i=0;i<this->_size;i++) {
        str.append(to_string(i + 1)).append(":").append(this->_animals[i]->toString() + "\n");
    }
	return str;
}


