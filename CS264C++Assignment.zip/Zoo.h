#ifndef ZOO_H
#define ZOO_H
// Importing needed files
#include "Animal.h"
// Defining scope
using namespace AnimalWorld;
// Creating layout for Zoo object
class Zoo{
    // Public attributes
	public:
        // Constructors
		Zoo(unsigned int);
        // Destructor
		~Zoo();
        // Various functions and attributes needed for object
		void addAnimal(Animal&);
		void addAnimal(Animal*);
		Animal* getAnimal(unsigned int);
		Animal** getAllAnimals();
		int size();
		string toString();

    // Private attributes to hold information and animal objects
	private:
		Animal** _animals;
		unsigned int _size;
		unsigned int _capacity;
};

#endif