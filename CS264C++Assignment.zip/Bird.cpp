// Importing needed files
#include "Bird.h"

// Making default constructor for Bird with no given arguments
Bird::Bird():Bird("[no name]",unknown, "nothing"){}

// Constructor for a Bird given a name and color
Bird::Bird(string name, Color color, string food){
    // Setting the name and color through the given function in the Animal object
	this->setName(name);
	this->setColor(color);
    this->setFood(food);
}

// Function to describe how the Bird performs
// This is done by returning a string of the needed information
string Bird::perform(){
	return "is performing by flying.";
}

// Function to gather the information of the Bird and returns all its properties in a string
// This is done by gathering all the information either through the Bird or Animal attributes
// then returning it in a string.
string Bird::toString(){
    return "Bird: " + this->getName() + " is " + this->getColor(this->getColor()) + ", is eating "+this->getFood() + " and " + this->perform();
}