#ifndef TEXASZOO_H
#define TEXASZOO_H

// Importing needed files
#include "Zoo.h"

// Creating the DublinZoo object extending off the Zoo object
class TexasZoo: public Zoo{
    // Public attributes
    public:
        // Constructor
        TexasZoo(unsigned int, string, string, string);
        // Various functions and attributes
        string getTime();
        string getWeather();
        string getCity();
    // Private attributes
    private:
        string _city;
        string _weather;
        string _showTime;
};

#endif
