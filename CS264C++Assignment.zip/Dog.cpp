// Importing needed files
#include "Dog.h"

// Making default constructor for Dog with no given arguments
Dog::Dog():Dog("[no name]", unknown, "nothing"){}

// Constructor for a Dog given a name and color
Dog::Dog(string name, Color color, string food){
    // Setting the name and color through the given function in the Animal object
	this->setName(name);
	this->setColor(color);
    this->setFood(food);
}

// Function to describe how the Dog performs
// This is done by returning a string of the needed information
string Dog::perform(){
    return "is performing by barking.";
}

// Function to gather the information of the Dog and returns all its properties in a string
// This is done by gathering all the information either through the Bird or Animal attributes
// then returning it in a string.
string Dog::toString(){
	return "Dog: " + this->getName() + " is " + this->getColor(this->getColor()) + ", eats " + this->getFood() + " and " + this->perform();
}
