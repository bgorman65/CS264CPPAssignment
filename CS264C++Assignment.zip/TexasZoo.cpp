// Importing needed files
#include "TexasZoo.h"

// Constructor for the DublinZoo class
TexasZoo::TexasZoo(unsigned int capacity, string showTime, string weather, string city): Zoo(capacity), _showTime(showTime), _weather(weather), _city(city){}

// Function to grab the show time from the object
string TexasZoo::getTime(){
    return this->_showTime;
}

// Function to grab the weather from the object
string TexasZoo::getWeather(){
    return this->_weather;
}

// Function to grab the city from the object
string TexasZoo::getCity(){
    return this->_city;
}