#ifndef DOG_H
#define DOG_H
// Importing needed files
#include "Animal.h"
// Defining scope
using namespace AnimalWorld;
// Creating layout of Dog object extending off the Animal object
class Dog : public Animal{
	// Public Attributes
    public:
        // Constructors
		Dog();
		Dog(string, Color, string);
        // Various functions and attributes needed for object
		string perform();
		string toString();
};

#endif
