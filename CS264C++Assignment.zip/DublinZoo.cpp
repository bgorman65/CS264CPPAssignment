// Importing needed files
#include "DublinZoo.h"

// Constructor for the DublinZoo class
DublinZoo::DublinZoo(unsigned int capacity, string showTime, string weather): Zoo(capacity), _showTime(showTime), _weather(weather){}

// Function to grab the show time from the object
string DublinZoo::getTime(){
    return this->_showTime;
}

// Function to grab the weather from the object
string DublinZoo::getWeather(){
    return this->_weather;
}