// Importing needed files
#include "Lion.h"

// Making default constructor for Lion with no given arguments
Lion::Lion():Lion("[no name]", unknown, "nothing"){}

// Constructor for a Lion given a name and color
Lion::Lion(string name, Color color, string food){
    // Setting the name and color through the given function in the Animal object
    this->setName(name);
    this->setColor(color);
    this->setFood(food);
}

// Function to describe how the Lion performs
// This is done by returning a string of the needed information
string Lion::perform(){
    return "is performing by roaring.";
}

// Function to gather the information of the Lion and returns all its properties in a string
// This is done by gathering all the information either through the Bird or Animal attributes
// then returning it in a string.
string Lion::toString(){
    return "Lion: " + this->getName() + " is " + this->getColor(this->getColor()) + ", is eating "+this->getFood() + " and " + this->perform();
}