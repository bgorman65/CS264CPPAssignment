#include "Animal.h"
using namespace AnimalWorld;

Animal::Animal():Animal("[no name]",unknown){
	this->_food="nothing";
}

Animal::Animal(string name, Animal::Color color, string food){
	this->_name=name;
	this->_color=color;
	this->_food=food;
}

Animal::Animal(string name, Animal::Color color){
	this->_name=name;
	this->_color=color;
	this->_food="nothing";
}

void Animal::setColor(Animal::Color color){
	this->_color=color;
}

Animal::Color Animal::getColor(){
	return this->_color;
}

void Animal::setFood(string food){
	this->_food=food;
}

string Animal::getFood(){
	return this->_food;
}

void Animal::setName(string name){
	this->_name=name;
}

string Animal::getName(){
	return this->_name;
}

string Animal::walk(){
	return "Animal: "+this->getName()+" is walking...";
}

string Animal::getColor(Animal::Color color){
	string str_color="";
	switch (this->_color){
		case red: str_color="red";break;
		case blue: str_color="blue";break;
		case green: str_color="green";break;
		case white: str_color="white";break;
		case brown: str_color="brown";break;
		case orange: str_color="orange";break;
		case yellow: str_color="yellow";break;
		case rainbow: str_color="rainbow";break;
		case unknown: str_color= "unknown";
	}
	
	return str_color;
}

string Animal::toString(){
	return  "Animal: "+this->getName()+" is "+this->getColor(this->_color)+" color and is eating "+this->_food;
}

