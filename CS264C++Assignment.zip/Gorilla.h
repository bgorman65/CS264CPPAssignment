#ifndef GORILLA_H
#define GORILLA_H
// Importing needed files
#include "Animal.h"
// Defining scope
using namespace AnimalWorld;
// Creating layout of Gorilla object extending off the Animal object
class Gorilla : public Animal{
    // Public Attributes
    public:
        // Constructors
        Gorilla();
        Gorilla(string, Color, string);
        // Various functions and attributes needed for object
        string perform();
        string toString();
};

#endif